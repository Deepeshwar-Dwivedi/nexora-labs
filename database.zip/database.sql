CREATE DATABASE IF NOT EXISTS nexora_labs CHARACTER SET utf8mb4 COLLATE utf8mb4_unicode_ci;
USE nexora_labs;

CREATE TABLE users (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100) NOT NULL,
  email VARCHAR(150) NOT NULL UNIQUE,
  password VARCHAR(255) NOT NULL,
  role ENUM('super_admin','admin','project_manager','support','client') DEFAULT 'client',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE services (
  id INT AUTO_INCREMENT PRIMARY KEY,
  slug VARCHAR(100) UNIQUE NOT NULL,
  title VARCHAR(150) NOT NULL,
  short_desc TEXT,
  icon VARCHAR(50),
  features TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE portfolio (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(150) NOT NULL,
  category VARCHAR(80),
  technology VARCHAR(200),
  description TEXT,
  image VARCHAR(255),
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE testimonials (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  designation VARCHAR(100),
  company VARCHAR(100),
  rating INT DEFAULT 5,
  review TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE faqs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  category VARCHAR(80),
  question TEXT,
  answer TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE blogs (
  id INT AUTO_INCREMENT PRIMARY KEY,
  title VARCHAR(200),
  slug VARCHAR(200) UNIQUE,
  category VARCHAR(80),
  excerpt TEXT,
  content LONGTEXT,
  author VARCHAR(100),
  reading_time INT DEFAULT 5,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE quotes (
  id INT AUTO_INCREMENT PRIMARY KEY,
  enquiry_id VARCHAR(30) UNIQUE,
  name VARCHAR(100),
  email VARCHAR(150),
  phone VARCHAR(30),
  company VARCHAR(150),
  service VARCHAR(100),
  budget VARCHAR(50),
  timeline VARCHAR(50),
  requirements TEXT,
  status ENUM('new','review','quoted','closed') DEFAULT 'new',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE consultations (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150),
  phone VARCHAR(30),
  company VARCHAR(150),
  service VARCHAR(100),
  preferred_date DATE,
  preferred_time VARCHAR(20),
  message TEXT,
  status ENUM('pending','confirmed','done') DEFAULT 'pending',
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

CREATE TABLE contact_enquiries (
  id INT AUTO_INCREMENT PRIMARY KEY,
  name VARCHAR(100),
  email VARCHAR(150),
  phone VARCHAR(30),
  subject VARCHAR(200),
  message TEXT,
  created_at TIMESTAMP DEFAULT CURRENT_TIMESTAMP
);

-- Demo Services
INSERT INTO services (slug,title,short_desc,icon,features) VALUES
('web-development','Website Development','Business websites, e‑commerce, landing pages and custom CMS.','bi-globe2','Business Websites, Corporate Websites, E‑commerce, Landing Pages, WordPress, Custom CMS'),
('software-development','Software Development','Custom software, ERP, CRM, HRMS and billing systems.','bi-cpu','Custom Software, ERP, CRM, HRMS, School Management, Inventory, Billing'),
('app-development','Application Development','Web apps, mobile apps, PWA and SaaS platforms.','bi-phone','Web Applications, Mobile Applications, PWA, SaaS Platforms'),
('ui-ux-design','UI/UX Design','Website UI, dashboard UI, design systems and prototypes.','bi-palette','Website UI, Dashboard UI, Mobile App UI, Design Systems, Prototypes'),
('ai-automation','AI & Automation','AI integration, chatbots, workflow and document automation.','bi-robot','AI Integration, Business Automation, AI Chatbots, Workflow Automation, Document Automation'),
('cloud-infra','Cloud & Infrastructure','Deployment, hosting, cloud migration and monitoring.','bi-cloud','Deployment, Hosting Setup, Cloud Migration, Database Setup, Monitoring'),
('digital-marketing','Digital Marketing','SEO, social media, performance marketing and content.','bi-megaphone','SEO, Social Media, Performance Marketing, Content Strategy'),
('maintenance','Maintenance & Support','Bug fixing, security, performance and backup.','bi-tools','Bug Fixing, Security, Performance Optimization, Backup, Technical Support');

-- Demo Portfolio
INSERT INTO portfolio (title,category,technology,description) VALUES
('School ERP','ERP','PHP, MySQL, Bootstrap','Complete school management with attendance, fees and exams.'),
('E‑commerce Store','E‑commerce','PHP, MySQL, Stripe','Multi‑vendor store with cart and payment gateway.'),
('CRM Dashboard','CRM','PHP, Chart.js','Sales pipeline, leads and reporting dashboard.'),
('Mobile Banking App','Mobile Apps','Flutter, Node.js','Secure mobile banking with notifications.');

-- Demo Testimonials
INSERT INTO testimonials (name,designation,company,rating,review) VALUES
('Rahul Mehta','CTO','EduCore','5','Nexora delivered our ERP ahead of schedule. Communication was excellent.'),
('Priya Sharma','Founder','ShopEasy','5','Our conversion rate jumped 38% after the new website. Highly recommended.'),
('Amit Verma','Director','FinTrust','4','Professional team, clean code and great post‑launch support.');

-- Demo FAQs
INSERT INTO faqs (category,question,answer) VALUES
('General','How long does a project take?','Typically 4–12 weeks depending on complexity.'),
('Pricing','Do you provide fixed‑price quotes?','Yes, after a discovery call we provide a detailed fixed‑price proposal.'),
('Support','Do you offer maintenance?','Yes, we have monthly maintenance plans starting from basic to enterprise.');

-- Demo Blogs
INSERT INTO blogs (title,slug,category,excerpt,content,author,reading_time) VALUES
('Why Every Business Needs a Custom CRM','why-custom-crm','Software','Off‑the‑shelf CRMs rarely fit. Here is why custom wins.','<p>Full article content here...</p>','Nexora Team',5),
('AI Automation for Small Businesses','ai-automation-smb','AI','Practical AI automations you can implement today.','<p>Full article content here...</p>','Nexora Team',7);